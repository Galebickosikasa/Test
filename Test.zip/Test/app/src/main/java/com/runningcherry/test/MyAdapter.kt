package com.runningcherry.test

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter : RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
    private var itemCount = 0

    inner class MyViewHolder internal constructor (itemView : View) : RecyclerView.ViewHolder(itemView) {
        private var btn : Button = itemView.findViewById(R.id.btn)
        private var text : TextView = itemView.findViewById(R.id.textView)
        private var pos = false

        fun bind (position : Int) {
            text.text = position.toString()
            btn.setOnClickListener {
                pos = !pos
                if (pos) text.text = position.toString()
                else text.text = (position * -100).toString()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.my_item, parent, false)
        return MyViewHolder (view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(position)
    }

    fun addItem () {
        ++itemCount
        notifyItemChanged (itemCount - 1)
    }

    override fun getItemCount(): Int {
        return itemCount
    }
}